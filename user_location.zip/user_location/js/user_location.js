/**
 * @file
 * Handle the form field behaviors.
 */
(function ($) {
    Drupal.behaviors.get_user_location = {
        attach: function (context, settings) {

            jQuery(".form-type-select select").change(function() {
                var thisval = jQuery(this).val();
                getdataonselectregion(thisval);
                //alert(thisval);
            });

            function getdataonselectregion(regvalue = false) {
               // alert('sfds');
               //  alert(regvalue);
                var selectedCountry = regvalue;
			    //$("#localization-menu-form .country-change-loader").show();

			    if(selectedCountry) {
			        var langauageCheckURL = "/user_location/region/location/"+selectedCountry;
			        $.ajax({
			            type: "POST",
			            url: langauageCheckURL,
			            data: selectedCountry,
			            dataType:"json",
			            success: function(data){
                            alert("success data"+data);
                        }
			        });
			    }
			}

        }
    };
})(jQuery);
