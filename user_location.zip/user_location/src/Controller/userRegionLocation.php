<?php

namespace Drupal\user_location\Controller;

class userRegionLocation {

  public function getlocationData($regionId) {
    return $regionId;
  }
  
}