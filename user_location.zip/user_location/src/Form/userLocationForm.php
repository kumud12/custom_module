<?php
/**
 * @file
 * Contains \Drupal\contact_forms\Form\userLocationForm.
 */
namespace Drupal\user_location\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Database;
use Drupal\Component\Utility\SafeMarkup;
use Drupal\Core\Datetime\DrupalDateTime;

class userLocationForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'business_ethics_form';
  }
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

     $form['country'] = array(
      '#type' => 'textfield',
      '#title' => t('Select the Country:'),     
      '#required' => TRUE,
    );
      
    $form['city'] = array(
      '#type' => 'textfield',
      '#title' => t('Select the City:'),     
      '#required' => TRUE,
    );

    $form['timezone']['country'] = array(
      '#type' => 'select',
      '#title' => t('Select the Timezone:'),
      '#required'=> TRUE,
      '#options' => listOfRegions(),
    );

  
    $form['businessEthics']['submit'] = array(
    '#type' => 'submit',
    '#value' => t('Submit'),
    );
   
    return $form;
  }

  /**
  * {@inheritdoc}
  */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
    $values = $form_state->getValues();
    if (empty($values['country'])) {
      $form_state->setErrorByName('country', $this->t('Country selection is required'));
    }
    if (empty($values['city'])) {
      $form_state->setErrorByName('city', $this->t('City selection is required'));
    }
    if (empty($values['firstName'])) {
      $form_state->setErrorByName('timezone', $this->t('TimeZone is required'));
    }
  }

  /**
  * {@inheritdoc}
  */
  public function submitForm(array &$form, FormStateInterface $form_state) {}
}
