<?php 
/**
 * @file
 * Contains \Drupal\user_location\Plugin\Block\userLocationBlock.
 */
namespace Drupal\user_location\plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormInterface;
use Drupal\Core\Form\FormStateInterface;
/**
 * Provides a 'User region Ethics Form' block.
 *
 * @Block(
 *   id = "user_region_block",
 *   admin_label = @Translation("User region block"),
 *   category = @Translation("Custom block")
 * )
 */
class userLocationBlock extends BlockBase {
  /**
  * {@inheritdoc}
  */  
  public function build() {
    $form = \Drupal::formBuilder()->getForm('Drupal\user_location\Form\userLocationForm');
    return $form;
  }

}